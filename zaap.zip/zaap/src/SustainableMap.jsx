import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import axios from "axios";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function SustainableMap() {
  const [wastePoints, setWastePoints] = useState([]);
  const [sustainableCompanies, setSustainableCompanies] = useState([]);
  const [climateData, setClimateData] = useState({ labels: [], datasets: [] });
  const [news, setNews] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");

  useEffect(() => {
    setWastePoints([
      { id: 1, name: "Posto de Coleta A", lat: -20.3155, lng: -40.3128, type: "plástico" },
      { id: 2, name: "Posto de Coleta B", lat: -20.3180, lng: -40.3100, type: "eletrônicos" }
    ]);

    axios.get("https://api.example.com/sustainable-companies").then((res) => {
      setSustainableCompanies(res.data);
    });

    axios.get("https://api.example.com/climate-data").then((res) => {
      setClimateData(res.data);
    });

    axios.get("https://api.example.com/sustainability-news").then((res) => {
      setNews(res.data);
    });
  }, []);

  return (
    <div className="w-full h-screen">
      <h1 className="text-2xl font-bold text-center my-4">Mapa Sustentável</h1>

      <div className="flex justify-center space-x-4 mb-4">
        <button onClick={() => setSelectedCategory("all")} className="px-4 py-2 bg-green-500 text-white rounded">Todos</button>
        <button onClick={() => setSelectedCategory("waste")} className="px-4 py-2 bg-blue-500 text-white rounded">Postos de Coleta</button>
        <button onClick={() => setSelectedCategory("companies")} className="px-4 py-2 bg-yellow-500 text-white rounded">Empresas Sustentáveis</button>
      </div>
      
      <MapContainer center={[-20.3155, -40.3128]} zoom={12} className="h-3/5 w-full">
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {selectedCategory === "all" || selectedCategory === "waste" ? wastePoints.map((point) => (
          <Marker key={point.id} position={[point.lat, point.lng]}>
            <Popup>{point.name} - Tipo: {point.type}</Popup>
          </Marker>
        )) : null}
        {selectedCategory === "all" || selectedCategory === "companies" ? sustainableCompanies.map((company) => (
          <Marker key={company.id} position={[company.lat, company.lng]}>
            <Popup>{company.name} - {company.description}</Popup>
          </Marker>
        )) : null}
      </MapContainer>
      
      <div className="p-4">
        <h2 className="text-xl font-bold text-center">Impacto da Reciclagem no Clima</h2>
        <Bar data={climateData} options={{ responsive: true, plugins: { legend: { display: true } } }} />
      </div>
      
      <div className="p-4">
        <h2 className="text-xl font-bold text-center">Notícias sobre Sustentabilidade</h2>
        <ul className="list-disc pl-6">
          {news.map((item, index) => (
            <li key={index} className="mb-2"><a href={item.url} target="_blank" rel="noopener noreferrer" className="text-blue-500 underline">{item.title}</a></li>
          ))}
        </ul>
      </div>
    </div>
  );
}