import SustainableMap from "./SustainableMap";

function App() {
  return (
    <div>
      <SustainableMap />
    </div>
  );
}

export default App;
